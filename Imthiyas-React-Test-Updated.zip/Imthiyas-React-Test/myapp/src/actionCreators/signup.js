import * as SIGNUP from '../actionTypes/signup';

export const signUpSubmitAction = (payload = {}) => {
    return (
        {
            type: SIGNUP.SIGNUP_SUBMIT,
            payload,
        }
    );
}

export const signUpSubmitSuccess = (data = {}) => {
    return (
        {
            type: SIGNUP.SIGNUP_SUBMIT_SUCCESS,
            data,
        }
    );
}

export const signUpSubmitFailure = (error = '') => {
    return (
        {
            type: SIGNUP.SIGNUP_SUBMIT_FAILURE,
            error,
        }
    );
}
