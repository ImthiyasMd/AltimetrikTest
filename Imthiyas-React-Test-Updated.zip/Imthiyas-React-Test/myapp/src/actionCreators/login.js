import * as LOGIN from '../actionTypes/login';

export const loginSubmitAction = (payload = {}) => {
    return (
        {
            type: LOGIN.LOGIN_SUBMIT,
            payload,
        }
    );
}

export const loginSubmitSuccess = (data = {}) => {
    return (
        {
            type: LOGIN.LOGIN_SUBMIT_SUCCESS,
            data,
        }
    );
}

export const loginSubmitFailure = (error = '') => {
    return (
        {
            type: LOGIN.LOGIN_SUBMIT_FAILURE,
            error,
        }
    );
}
