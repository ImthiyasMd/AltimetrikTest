import React from 'react';
// import logo from './logo.svg';
import './App.css';
import FormsContainer from './containers/forms.js'

function App() {
  return (
    <div className="App">
      <FormsContainer></FormsContainer>
    </div>
  );
}

export default App;
