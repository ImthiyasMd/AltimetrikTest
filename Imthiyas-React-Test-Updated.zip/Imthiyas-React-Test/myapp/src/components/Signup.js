import React, { Component } from 'react';

class Signupform extends Component {
  constructor(props) {
    super(props);
    this.state = {
      signUpDetails: {},
    };
  }

  /* Info: When the form input has been changes, this method will be trigger */
  inputChanges = (e) => {
    let id = e.target.id;
    const value = e.target.value;
    id = (id.indexOf('gender') > -1) ? 'gender' : id;
    let signUpData = this.state.signUpDetails;
    signUpData = {
      ...signUpData,
      [id]: value,
    }
    console.log(signUpData);
    this.setState({
      signUpDetails: signUpData,
    });
  }

  /*Info: When the form has been submitted, this method will be trigger */
  signupFormSubmit = (e) => {
    e.preventDefault();
    let isFormValid = true;
    let signUpData = this.state.signUpDetails;
    for (let key in signUpData) {
      if (!signUpData[key]) {
        isFormValid = false;
      }
    }
    let countrySelected = signUpData.country.toLowerCase();
    countrySelected = countrySelected.includes('choose country');
    if (!isFormValid || countrySelected) {
      alert("Please enter all the details.")
    } else {
      this.props.signUpSubmitCall(signUpData);
      alert("POST Api call triggered");
    }
  }

  render() {
    const { signUpDetails = {} } = this.state;
    const {
      userName,
      password,
      email,
      firstName,
      lastName,
      country,
    } = signUpDetails;
    return (
      <React.Fragment>
        <h3>Signup Form</h3>
        <form name="SignupForm" className="signUpForm" action="" autoComplete="off">
          <div>
            <label>Username</label>
            <input id="userName" type="text" value={userName} onChange={this.inputChanges} />
          </div>
          <div>
            <label>Password</label>
            <input id="password" type="password" value={password} onChange={this.inputChanges} />
          </div>
          <div>
            <label>Email</label>
            <input id="email" type="email" value={email} onChange={this.inputChanges} />
          </div>
          <div>
            <label>First Name</label>
            <input id="firstName" type="text" value={firstName} onChange={this.inputChanges} />
          </div>
          <div>
            <label>Last Name</label>
            <input id="lastName" type="text" value={lastName} onChange={this.inputChanges} />
          </div>
          <div>
            <label>Gender</label>
            <input id="genderMale" type="radio" name="gender" value="Male" onChange={this.inputChanges} />
            <label htmlFor="genderMale">Male</label>
            <input id="genderFemale" type="radio" name="gender" value="Female" onChange={this.inputChanges} />
            <label htmlFor="genderFemale">Female</label>
            <input id="genderOther" type="radio" name="gender" value="Other" onChange={this.inputChanges} />
            <label htmlFor="genderOther">Other</label>
            {/* <input type="radio" name="gender" value="female">Female</input>
                        <input type="radio" name="gender" value="other">Other</input> */}
          </div>
          <div>
            <label>Country</label>
            <select id="country" value={country} onChange={this.inputChanges}>
              <option>Choose Country</option>
              <option>India</option>
              <option>United States</option>
              <option>United Kingdom</option>
            </select>
          </div>
          <input type="submit" value="Submit" id="submit" onClick={this.signupFormSubmit} />
        </form>
      </React.Fragment>
    )
  }
}

export default Signupform;