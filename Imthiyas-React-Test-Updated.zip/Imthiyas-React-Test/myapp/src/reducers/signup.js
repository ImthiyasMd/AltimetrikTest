import * as SIGNUP from '../actionTypes/signup';

const initialState = {
    isLoading: false,
    signUpData: {},
    signUpError: '',
};

export default function signUpReducer(state = initialState, action) {
    switch (action.type) {
        case SIGNUP.SIGNUP_SUBMIT:
            return {
                ...state,
                isLoading: true,
            }
        case SIGNUP.SIGNUP_SUBMIT_SUCCESS:
            return {
                ...state,
                isLoading: false,
                signUpData: action.data,
            }
        case SIGNUP.SIGNUP_SUBMIT_FAILURE:
            return {
                ...state,
                isLoading: false,
                signUpError: action.error,
            }
        default:
            return state;
    }
}