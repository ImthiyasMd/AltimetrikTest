import * as LOGIN from '../actionTypes/login';

const initialState = {
    isLoading: false,
    loginData: {},
    loginError: '',
};

export default function loginReducer(state = initialState, action) {
    switch (action.type) {
        case LOGIN.LOGIN_SUBMIT:
            return {
                ...state,
                isLoading: true,
            }
        case LOGIN.LOGIN_SUBMIT_SUCCESS:
            return {
                ...state,
                isLoading: false,
                loginData: action.data,
            }
        case LOGIN.LOGIN_SUBMIT_FAILURE:
            return {
                ...state,
                isLoading: false,
                loginError: action.error,
            }
        default:
            return state;
    }
}