import React from 'react';
import { Provider } from 'react-redux'
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { createBrowserHistory } from 'history';
import Signupform from "./components/Signup";
import Loginform from "./components/Login";

const history = createBrowserHistory();

const AppRouter = () => (
    <Router history={history}>
        <Switch>
            <Route path="/" exact component={Signupform} />
            <Route path="/signup" component={Signupform} />
            <Route path="/login" component={Loginform} />
        </Switch>
    </Router>
);

export default AppRouter;