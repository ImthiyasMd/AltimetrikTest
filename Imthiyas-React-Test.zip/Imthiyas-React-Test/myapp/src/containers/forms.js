import React, { Component } from 'react';
import { connect } from "react-redux";
import Signupform from '../components/Signup';
import Loginform from '../components/Login';
import { signUpSubmitAction, signUpSubmitSuccess } from '../actionCreators/signup';
import { loginSubmitAction, loginSubmitSuccess } from '../actionCreators/login';

class FormsContainer extends Component {

  /*Info: Post API call for the signup form */
  dispatchSignUpAction = (obj) => {
    this.props.signUpSubmitAction(obj);
    fetch('http://localhost:3001/signUpForm', {
      method: 'post',
      headers: {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(obj)
    }).then(res => res.json())
      .then((result) => {
        this.props.signUpSubmitSuccess(obj);
      },
        (error) => {
          console.log(error);
        }
      );
  }

  /*Info: GET API call for the login form */
  dispatchLoginAction = (obj) => {
    this.props.loginSubmitAction(obj);
    fetch('http://localhost:3001/loginForm', {
      method: 'get',
    }).then(res => res.json())
      .then((result) => {
        this.props.loginSubmitSuccess(obj);
      },
        (error) => {
          console.log(error);
        }
      );
  }


  render() {
    return (
      <div className="container">
        <Signupform signUpSubmitCall={this.dispatchSignUpAction}></Signupform>
        <Loginform loginSubmitCall={this.dispatchLoginAction}></Loginform>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  signUpSubmitAction: (payload) => dispatch(signUpSubmitAction(payload)),
  signUpSubmitSuccess: (data) => dispatch(signUpSubmitSuccess(data)),
  loginSubmitAction: (payload) => dispatch(loginSubmitAction(payload)),
  loginSubmitSuccess: (data) => dispatch(loginSubmitSuccess(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(FormsContainer);