import React, { Component } from 'react';

class Loginform extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loginDetails: {},
    };
  }

  /* Info: When the form input has been changes, this method will be trigger */
  inputChanges = (e) => {
    let id = e.target.id;
    const value = e.target.value;
    let loginData = this.state.loginDetails;
    loginData = {
      ...loginData,
      [id]: value,
    }
    console.log(loginData);
    this.setState({
      loginDetails: loginData,
    });
  }

  /*Info: When the form has been submitted, this method will be trigger */
  loginFormSubmit = (e) => {
    e.preventDefault();
    let isFormValid = true;
    let loginData = this.state.loginDetails;
    for (let key in loginData) {
      if (!loginData[key]) {
        isFormValid = false;
      }
    }
    if (!isFormValid) {
      alert("Please enter all the details.")
    } else {
      this.props.loginSubmitCall(loginData);
      alert("GET Api call triggered");
    }
  }

  render() {
    const { loginDetails = {} } = this.state;
    const {
      userName,
      password
    } = loginDetails;
    return (
      <React.Fragment>
        <h3>Login Form</h3>
        <form name="LoginForm" className="LoginForm" action="" autoComplete="off">
          <div>
            <label>Username</label>
            <input id="userName" type="text" value={userName} onChange={this.inputChanges} />
          </div>
          <div>
            <label>Password</label>
            <input id="password" type="password" value={password} onChange={this.inputChanges} />
          </div>
          <input type="submit" value="Submit" id="submit" onClick={this.loginFormSubmit} />
        </form>
      </React.Fragment>
    )
  }
}

export default Loginform;