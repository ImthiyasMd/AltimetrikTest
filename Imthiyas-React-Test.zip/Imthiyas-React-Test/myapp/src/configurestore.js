import { createStore } from "redux";
import reducer from "./rootreducers";

const preloadedState = {};

function configureStore(state = preloadedState) {
    return createStore(reducer, state);
}

export default configureStore;