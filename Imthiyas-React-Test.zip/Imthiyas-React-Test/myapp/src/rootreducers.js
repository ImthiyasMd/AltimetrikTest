import { combineReducers } from 'redux';
import signUpReducer from './reducers/signup';
import loginReducer from './reducers/Login';

export default combineReducers({
    signUpReducer,
    loginReducer
});